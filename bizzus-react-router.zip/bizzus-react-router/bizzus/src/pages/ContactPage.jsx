import Contact from '../components/Contact';

export default function ContactPage({ toast }) {
  return <Contact toast={toast} />;
}
